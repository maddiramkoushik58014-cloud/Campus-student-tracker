"""
app_cli.py
----------
Command-line interface for the Student Management System.
Run with: python app_cli.py
"""

import database as db


def pause():
    input("\nPress Enter to continue...")


def print_header(title):
    print("\n" + "=" * 45)
    print(f"{title.center(45)}")
    print("=" * 45)


def menu_add_student():
    print_header("Add New Student")
    name = input("Name: ").strip()
    roll_no = input("Roll No: ").strip()
    student_class = input("Class: ").strip()
    dob = input("Date of Birth (YYYY-MM-DD): ").strip()
    gender = input("Gender: ").strip()
    contact_no = input("Contact No: ").strip()
    address = input("Address: ").strip()
    email = input("Email: ").strip()
    try:
        db.add_student(name, roll_no, student_class, dob, gender, contact_no, address, email)
        print("\n✅ Student added successfully!")
    except Exception as e:
        print(f"\n❌ Error: {e}")
    pause()


def menu_view_students():
    print_header("All Students")
    rows = db.get_all_students()
    if not rows:
        print("No students found.")
    for r in rows:
        print(f"ID:{r[0]} | {r[1]} | Roll:{r[2]} | Class:{r[3]} | Contact:{r[6]}")
    pause()


def menu_search_student():
    print_header("Search Student")
    keyword = input("Enter name / roll no / class to search: ").strip()
    rows = db.search_students(keyword)
    if not rows:
        print("No matching students found.")
    for r in rows:
        print(f"ID:{r[0]} | {r[1]} | Roll:{r[2]} | Class:{r[3]}")
    pause()


def menu_update_student():
    print_header("Update Student")
    student_id = input("Enter Student ID to update: ").strip()
    student = db.get_student_by_id(student_id)
    if not student:
        print("Student not found.")
        pause()
        return
    print("Leave a field blank to keep it unchanged.")
    fields = {}
    for label, key in [("Name", "name"), ("Class", "class"),
                        ("Contact No", "contact_no"), ("Address", "address"),
                        ("Email", "email")]:
        value = input(f"{label}: ").strip()
        if value:
            fields[key] = value
    if fields:
        db.update_student(student_id, **fields)
        print("\n✅ Student updated successfully!")
    else:
        print("\nNo changes made.")
    pause()


def menu_delete_student():
    print_header("Delete Student")
    student_id = input("Enter Student ID to delete: ").strip()
    confirm = input(f"Are you sure you want to delete student {student_id}? (y/n): ").strip().lower()
    if confirm == "y":
        db.delete_student(student_id)
        print("\n✅ Student deleted successfully!")
    else:
        print("Cancelled.")
    pause()


def menu_attendance():
    print_header("Mark Attendance")
    student_id = input("Student ID: ").strip()
    date = input("Date (YYYY-MM-DD): ").strip()
    status = input("Status (Present/Absent): ").strip().capitalize()
    try:
        db.mark_attendance(student_id, date, status)
        print("\n✅ Attendance recorded!")
    except Exception as e:
        print(f"\n❌ Error: {e}")
    pause()


def menu_view_attendance():
    print_header("View Attendance")
    student_id = input("Student ID: ").strip()
    rows = db.get_attendance(student_id)
    if not rows:
        print("No attendance records found.")
    for date, status in rows:
        print(f"{date} : {status}")
    pause()


def menu_add_marks():
    print_header("Add Marks")
    student_id = input("Student ID: ").strip()
    subject = input("Subject: ").strip()
    obtained = int(input("Marks Obtained: ").strip())
    total = int(input("Total Marks: ").strip())
    db.add_marks(student_id, subject, obtained, total)
    print("\n✅ Marks recorded!")
    pause()


def menu_view_result():
    print_header("Result / Marksheet")
    student_id = input("Student ID: ").strip()
    rows = db.get_marks(student_id)
    if not rows:
        print("No marks found.")
    for subject, obtained, total in rows:
        print(f"{subject:<15} {obtained}/{total}")
    obtained_total, max_total, pct = db.get_result_summary(student_id)
    print("-" * 30)
    print(f"Total: {obtained_total}/{max_total}   Percentage: {pct}%")
    pause()


def menu_add_fee():
    print_header("Add Fee Record")
    student_id = input("Student ID: ").strip()
    amount = float(input("Amount Paid: ").strip())
    date = input("Payment Date (YYYY-MM-DD): ").strip()
    status = input("Status (Paid/Pending/Partial): ").strip().capitalize()
    db.add_fee_record(student_id, amount, date, status)
    print("\n✅ Fee record added!")
    pause()


def menu_view_fees():
    print_header("Fee Records")
    student_id = input("Student ID: ").strip()
    rows = db.get_fee_records(student_id)
    if not rows:
        print("No fee records found.")
    for amount, date, status in rows:
        print(f"{date} | Amount: {amount} | Status: {status}")
    pause()


MENU_OPTIONS = {
    "1": ("Add Student", menu_add_student),
    "2": ("View All Students", menu_view_students),
    "3": ("Search Student", menu_search_student),
    "4": ("Update Student", menu_update_student),
    "5": ("Delete Student", menu_delete_student),
    "6": ("Mark Attendance", menu_attendance),
    "7": ("View Attendance", menu_view_attendance),
    "8": ("Add Marks", menu_add_marks),
    "9": ("View Result / Marksheet", menu_view_result),
    "10": ("Add Fee Record", menu_add_fee),
    "11": ("View Fee Records", menu_view_fees),
    "0": ("Exit", None),
}


def main():
    db.init_db()
    while True:
        print_header("STUDENT MANAGEMENT SYSTEM")
        for key, (label, _) in MENU_OPTIONS.items():
            print(f" {key}. {label}")
        choice = input("\nEnter your choice: ").strip()

        if choice == "0":
            print("\nGoodbye!")
            break

        option = MENU_OPTIONS.get(choice)
        if option:
            option[1]()
        else:
            print("\n❌ Invalid choice. Try again.")
            pause()


if __name__ == "__main__":
    main()
